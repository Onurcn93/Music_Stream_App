#include "MusicStream.h"

#include <iostream>

void MusicStream::addProfile(const std::string &email, const std::string &username, SubscriptionPlan plan) {
    Profile * new_profile = new Profile(email, username, plan);
    this->profiles.insertAtTheEnd(*new_profile);
}

void MusicStream::deleteProfile(const std::string &email) {
    Node<Profile>* node = this->profiles.getFirstNode();
    while (node) {
        if (node->data.getEmail() == email) {
            // 1. clearing followers' following list
            LinkedList<Profile*> follower_list = node->data.getFollowers();
            for (int i = 0; i < follower_list.getSize(); i++) {
                follower_list.getNodeAtIndex(i)->data->unfollowProfile(&(node->data));
            }
            // 2. clearing following's follower list
            LinkedList<Profile*> following_list = node->data.getFollowings();
            for (int j = 0; j < following_list.getSize(); j++) {
                following_list.getNodeAtIndex(j)->data->getFollowers().removeNode(&(node->data));
            }
            // 3. remove the user
            this->profiles.removeNode(node);
            break;
        }
        node = node->next;
        // profile is not in the app
        if (node == this->profiles.getFirstNode()) {
            break;
        }
    }
}

void MusicStream::addArtist(const std::string &artistName) {
    Artist * new_artist = new Artist(artistName);
    this->artists.insertAtTheEnd(*new_artist);
}

void MusicStream::addAlbum(const std::string &albumName, int artistId) {
    Album * new_album = new Album(albumName);
    // 1. add album to music app album list
    this->albums.insertAtTheEnd(*new_album);
    // 2. update artist's album list
    for (int i = 0; i < artists.getSize(); i++) {
        if (artists.getNodeAtIndex(i)->data.getArtistId() == artistId) {
            artists.getNodeAtIndex(i)->data.addAlbum(new_album);
        }
    }
}

void MusicStream::addSong(const std::string &songName, int songDuration, int albumId) {
    Song * new_song = new Song(songName, songDuration);
    // 1. add song to music app song list
    this->songs.insertAtTheEnd(*new_song);
    // 2. update album's song list
    for (int j = 0; j < artists.getSize(); j++) {
        for (int i = 0; i < artists.getNodeAtIndex(j)->data.getAlbums().getSize(); i++) {
            if (artists.getNodeAtIndex(j)->data.getAlbums().getNodeAtIndex(i)->data->getAlbumId() == albumId) {
                artists.getNodeAtIndex(j)->data.getAlbums().getNodeAtIndex(i)->data->addSong(new_song);
            }
    
        }
    } 
    for (int i = 0; i < albums.getSize(); i++) {
        if (albums.getNodeAtIndex(i)->data.getAlbumId() == albumId) {
            albums.getNodeAtIndex(i)->data.addSong(new_song);
        }
    }
    
}

void MusicStream::followProfile(const std::string &email1, const std::string &email2) {
    bool profile1_found = false;
    bool profile2_found = false;
    int profile1_pos;
    int profile2_pos;

    for (int i = 0; i < profiles.getSize(); i++) {
        if (profiles.getNodeAtIndex(i)->data.getEmail() == email1) {
            profile1_pos = i;
            profile1_found = true;
        }
        if (profiles.getNodeAtIndex(i)->data.getEmail() == email2) {
            profile2_pos = i;
            profile2_found = true;
        }
        if (profile1_found && profile2_found) {
            profiles.getNodeAtIndex(profile1_pos)->data.followProfile(&(profiles.getNodeAtIndex(profile2_pos)->data));
            break;
        }
    }

}

void MusicStream::unfollowProfile(const std::string &email1, const std::string &email2) {
    bool profile1_found = false;
    bool profile2_found = false;
    int profile1_pos;
    int profile2_pos;

    for (int i = 0; i < profiles.getSize(); i++) {
        if (profiles.getNodeAtIndex(i)->data.getEmail() == email1) {
            profile1_pos = i;
            profile1_found = true;
        }
        if (profiles.getNodeAtIndex(i)->data.getEmail() == email2) {
            profile2_pos = i;
            profile2_found = true;
        }
        if (profile1_found && profile2_found) {
            profiles.getNodeAtIndex(profile1_pos)->data.unfollowProfile(&(profiles.getNodeAtIndex(profile2_pos)->data));
            break;
        }
    }
}

void MusicStream::createPlaylist(const std::string &email, const std::string &playlistName) {
    Profile * profile_to_update;
    for (int i = 0; i < profiles.getSize(); i++) {
        if (profiles.getNodeAtIndex(i)->data.getEmail() == email) {
            profile_to_update = &(profiles.getNodeAtIndex(i)->data);
            profile_to_update->createPlaylist(playlistName);
            break;
        }
    }
}

void MusicStream::deletePlaylist(const std::string &email, int playlistId) {
    Profile * profile_to_update;
    for (int i = 0; i < profiles.getSize(); i++) {
        if (profiles.getNodeAtIndex(i)->data.getEmail() == email) {
            profile_to_update = &(profiles.getNodeAtIndex(i)->data);
            profile_to_update->deletePlaylist(playlistId);
            break;
        }
    }
}

void MusicStream::addSongToPlaylist(const std::string &email, int songId, int playlistId) {
    int song_list_pos;

    for (int i = 0; i < songs.getSize(); i++) {
        if (songs.getNodeAtIndex(i)->data.getSongId() == songId) {
            song_list_pos = i;
            break;
        }
    }

    Song* song_to_add = &(songs.getNodeAtIndex(song_list_pos)->data);

    for (int i = 0; i < profiles.getSize(); i++) {
        if (profiles.getNodeAtIndex(i)->data.getEmail() == email) {
            profiles.getNodeAtIndex(i)->data.getPlaylist(playlistId)->addSong(song_to_add);
            break;
        }
    }
}

void MusicStream::deleteSongFromPlaylist(const std::string &email, int songId, int playlistId) {
    int song_list_pos;

    for (int i = 0; i < songs.getSize(); i++) {
        if (songs.getNodeAtIndex(i)->data.getSongId() == songId) {
            song_list_pos = i;
            break;
        }
    }

    Song* song_to_drop = &(songs.getNodeAtIndex(song_list_pos)->data);

    for (int i = 0; i < profiles.getSize(); i++) {
        if (profiles.getNodeAtIndex(i)->data.getEmail() == email) {
            profiles.getNodeAtIndex(i)->data.getPlaylist(playlistId)->dropSong(song_to_drop);
            break;
        }
    }
}

LinkedList<Song *> MusicStream::playPlaylist(const std::string &email, Playlist *playlist) {
    Profile user_profile;
    for (int i = 0; i < profiles.getSize(); i++) {
        if (profiles.getNodeAtIndex(i)->data.getEmail() == email) {
            user_profile = profiles.getNodeAtIndex(i)->data;
            if (user_profile.getPlan() == premium) {
                return playlist->getSongs();
            }
            else {
                LinkedList<Song*> advertised_song_list = playlist->getSongs();
                advertised_song_list.insertAsEveryKthNode(&(Song::ADVERTISEMENT_SONG), 2);
                return advertised_song_list;
            }
            break;
        }
    }
}

Playlist *MusicStream::getPlaylist(const std::string &email, int playlistId) {
    Node<Profile>* user_profile = this->profiles.getFirstNode();
    // find correct profile
    while (user_profile) {
        if (user_profile->data.getEmail() == email) {
            // find correct playlist
            Node<Playlist>* required_playlist = user_profile->data.getPlaylists().getFirstNode();
            while (required_playlist) {
                if (required_playlist->data.getPlaylistId() == playlistId) {
                    return &(required_playlist->data);
                    break;
                }
                required_playlist = required_playlist->next;
            }
            break;
        }
        user_profile = user_profile->prev;
    }
}

LinkedList<Playlist *> MusicStream::getSharedPlaylists(const std::string &email) {
    LinkedList<Playlist*> share_list;
    Node<Profile>* user_profile = this->profiles.getFirstNode();
    // find correct profile
    while (user_profile) {
        if (user_profile->data.getEmail() == email) {
            // access following list
            for (int j = 0; j < user_profile->data.getFollowings().getSize(); j++) {
                Node<Profile *> current_followed = user_profile->data.getFollowings().getNodeAtIndex(j)->data;
                for (int g = 0; g < (*(current_followed.data)).getPlaylists().getSize(); g++) {
                    if ((*(current_followed.data)).getPlaylists().getNodeAtIndex(g)->data.isShared()) {
                        share_list.insertAtTheEnd(&((*(current_followed.data)).getPlaylists().getNodeAtIndex(g)->data));
                    }
                }
            }
            break;
        }
        user_profile = user_profile->next;
    }
    return share_list;
}

void MusicStream::shufflePlaylist(const std::string &email, int playlistId, int seed) {
    Node<Profile>* user_profile = this->profiles.getFirstNode();
    // find correct profile
    while (user_profile) {
        if (user_profile->data.getEmail() == email) {
            user_profile->data.shufflePlaylist(playlistId, seed);
            break;
        }
        user_profile = user_profile->next;
    }
}

void MusicStream::sharePlaylist(const std::string &email, int playlistId) {
    Node<Profile>* user_profile = this->profiles.getFirstNode();
    // find correct profile
    while (user_profile) {
        if (user_profile->data.getEmail() == email) {
            user_profile->data.sharePlaylist(playlistId);
            break;
        }
        user_profile = user_profile->next;
    }
}

void MusicStream::unsharePlaylist(const std::string &email, int playlistId) {
    Node<Profile>* user_profile = this->profiles.getFirstNode();
    // find correct profile
    while (user_profile) {
        if (user_profile->data.getEmail() == email) {
            user_profile->data.unsharePlaylist(playlistId);
            break;
        }
        user_profile = user_profile->next;
    }
}

void MusicStream::subscribePremium(const std::string &email) {
    Node<Profile>* user_profile = this->profiles.getFirstNode();
    // find correct profile
    while (user_profile) {
        if (user_profile->data.getEmail() == email) {
            user_profile->data.setPlan(premium);
            break;
        }
        user_profile = user_profile->next;
    }
}

void MusicStream::unsubscribePremium(const std::string &email) {
    Node<Profile>* user_profile = this->profiles.getFirstNode();
    // find correct profile
    while (user_profile) {
        if (user_profile->data.getEmail() == email) {
            user_profile->data.setPlan(free_of_charge);
            break;
        }
        user_profile = user_profile->next;
    }
}

void MusicStream::print() const {
    std::cout << "# Printing the music stream ..." << std::endl;

    std::cout << "# Number of profiles is " << this->profiles.getSize() << ":" << std::endl;
    this->profiles.print();

    std::cout << "# Number of artists is " << this->artists.getSize() << ":" << std::endl;
    this->artists.print();

    std::cout << "# Number of albums is " << this->albums.getSize() << ":" << std::endl;
    this->albums.print();

    std::cout << "# Number of songs is " << this->songs.getSize() << ":" << std::endl;
    this->songs.print();

    std::cout << "# Printing is done." << std::endl;
}
