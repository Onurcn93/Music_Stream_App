#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>

#include "Node.h"

template<class T>
class LinkedList {
public: // DO NOT CHANGE THIS PART.
    LinkedList();
    LinkedList(const LinkedList<T> &obj);

    ~LinkedList();

    int getSize() const;
    bool isEmpty() const;
    bool contains(Node<T> *node) const;

    Node<T> *getFirstNode() const;
    Node<T> *getLastNode() const;
    Node<T> *getNode(const T &data) const;
    Node<T> *getNodeAtIndex(int index) const;

    void insertAtTheFront(const T &data);
    void insertAtTheEnd(const T &data);
    void insertAfterNode(const T &data, Node<T> *node);
    void insertAsEveryKthNode(const T &data, int k);

    void removeNode(Node<T> *node);
    void removeNode(const T &data);
    void removeAllNodes();
    void removeEveryKthNode(int k);

    void swap(Node<T> *node1, Node<T> *node2);
    void shuffle(int seed);

    void print(bool reverse=false) const;

    LinkedList<T> &operator=(const LinkedList<T> &rhs);


private: // YOU MAY ADD YOUR OWN UTILITY MEMBER FUNCTIONS HERE.
    
    Node<T>* findPrevious(const T& data);

private: // DO NOT CHANGE THIS PART.
    Node<T> *head;

    int size;
};

template<class T>
LinkedList<T>::LinkedList() {
    this->head = NULL;
    this->size = 0;
}

template<class T>
LinkedList<T>::LinkedList(const LinkedList<T> &obj) {
    this->head = NULL;
    this->size = 0;
    *this = obj;
    
}

template<class T>
LinkedList<T>::~LinkedList() {
    removeAllNodes();
    delete head;
}

template<class T>
int LinkedList<T>::getSize() const {
    return size;
}

template<class T>
bool LinkedList<T>::isEmpty() const {
    return head == NULL;
}

template<class T>
bool LinkedList<T>::contains(Node<T> *node) const {
    // check list is empty
    if (isEmpty()) {
        return false;
    }
    else {
        Node<T>* p = getFirstNode();
        Node<T>* start = getFirstNode();
        while (p) {
            std::cout << p << " comparing p with node = " << node << std::endl;
            if (p == node) {
                return true;
            }
            p = p->next;
            if (p == start) {
                // Node is not in the list
                return false;
            }
        }
    }
}

template<class T>
Node<T> *LinkedList<T>::getFirstNode() const {
    return head;
}

template<class T>
Node<T> *LinkedList<T>::getLastNode() const {
    if (head) {
        return head->prev;
    }
    return NULL;
}

template<class T>
Node<T> *LinkedList<T>::getNode(const T &data) const {
    Node<T>* p = getFirstNode();
    Node<T>* start = getFirstNode();
    while (p) {
        if (p->data == data) {
            return p;
        }
        p = p->next;
        if (p == start) {
            // Node is not in the list
            return NULL;
        }
    }
}

template<class T>
Node<T> *LinkedList<T>::getNodeAtIndex(int index) const {
    int temp_index = 0;
    Node<T>* p = getFirstNode();
    while (temp_index < size) {
        if (temp_index == index) {
            return p;
        }
        temp_index++;
        p = p->next;
    }
    return NULL;
}

template<class T>
void LinkedList<T>::insertAtTheFront(const T &data) {
    // list is empty
    if (isEmpty()){
        Node<T> *new_node = new Node<T>(data);
        new_node->next = new_node;
        new_node->prev = new_node;
        this->head = new_node;
    }
    // list is not empty
    else {
        Node<T>* new_node = new Node<T>(data, getLastNode(), getFirstNode());
        getLastNode()->next = new_node;
        getFirstNode()->prev = new_node;
        this->head = new_node;
    }
    this->size += 1;
}

template<class T>
void LinkedList<T>::insertAtTheEnd(const T &data) {
    // list is empty
    if (isEmpty()) {
        Node<T>* new_node = new Node<T>(data);
        new_node->next = new_node;
        new_node->prev = new_node;
        this->head = new_node;
    }
    // list is not empty
    else {
        Node<T>* new_node = new Node<T>(data, getLastNode(), getFirstNode());
        getLastNode()->next = new_node;
        getFirstNode()->prev = new_node;
    }
    this->size += 1;
}

template<class T>
void LinkedList<T>::insertAfterNode(const T &data, Node<T> *node) {
    
    Node<T>* p = getFirstNode();
    while (p) {
        if (p == node && p != getLastNode()) {
            Node<T>* new_node = new Node<T>(data);
            new_node->next = p->next;
            new_node->prev = p;
            p->next->prev = new_node;
            p->next = new_node;
            this->size += 1;
            break;
        }
        else if (p == node && p == getLastNode()) {
            insertAtTheFront(data);
        }
        p = p->next;
        if (p == getFirstNode()) {
            // Node is not in the list
            break;
        }
    }
}

template<class T>
void LinkedList<T>::insertAsEveryKthNode(const T &data, int k) {
    if (k >= 2) {
        int temp_index = 1;
        while (temp_index <= size) {
            if ((temp_index % k) == 0) {
                Node<T>* previous = getNodeAtIndex(temp_index - 2); // index correction for previous node -2
                insertAfterNode(data, previous);
            }
            temp_index++;
        }
        // correction for inserting last elemen if it were to also increase the list size
        if ((size + 1) % k == 0) {
            insertAtTheEnd(data);
        }
    }
}

template<class T>
void LinkedList<T>::removeNode(Node<T> *node) {
    Node<T>* temp = getNode(node->data);
    // check if there exits such a node
    if (temp == NULL) {
        return;
    }
    else {
        temp->prev->next = temp->next;
        temp->next->prev = temp->prev;
        this->size -= 1;
        // No node left
        if (size == 0) {
            head = NULL;
        }
        // deleted the first node
        if (temp == getFirstNode()) {
            head = temp->next;
        }       
    }
    delete temp;
}

template<class T>
void LinkedList<T>::removeNode(const T &data) {
    Node<T>* temp = getNode(data);
    // check if there exits such a node
    if (temp == NULL) {
        return;
    }
    else {
        temp->prev->next = temp->next;
        temp->next->prev = temp->prev;
        this->size -= 1;
        // No node left
        if (size == 0) {
            head = NULL;
        }
        // deleted the first node
        if (temp == getFirstNode()) {
            head = temp->next;
        }
        delete temp;
    }
}

template<class T>
void LinkedList<T>::removeAllNodes() {
    while (!isEmpty()) {
        removeNode(getFirstNode()->data);
    }
}

template<class T>
void LinkedList<T>::removeEveryKthNode(int k) {
    if (k >= 2 && !isEmpty()) {
        Node<T>* p = getFirstNode();
        int len = size;
        int deletion = 0;
        for (int temp_index = 1; temp_index <= len; temp_index++) {
            if (temp_index % k == 0) {
                removeNode(getNodeAtIndex(temp_index - deletion - 1));
                deletion++;
            }
        }
    }
}

template<class T>
void LinkedList<T>::swap(Node<T> *node1, Node<T> *node2) {
    if (getNode(node1->data) == NULL || getNode(node2->data) == NULL) {
        // not in the list
        return;
    }
    else if (node1 == node2) {
        // same node
        return;
    }

    if (head == node1 || head == node2) {
        // head update if either node1 or node 2 is first
        if (head == node1) {
            head = node2;
        }
        else {
            head = node1;
        }    
    }

    // if nodes are not adjacent
    if (!(node1->prev == node2 || node2->prev == node1)) {
        // creating pointer variables not new *Nodes*
        Node<T>* next_node2 = node2->next;
        Node<T>* prev_node2 = node2->prev;

        node2->next = node1->next;
        node2->prev = node1->prev;
        node1->next = next_node2;
        node1->prev = prev_node2;

        node2->prev->next = node2;
        node2->next->prev = node2;
        node1->prev->next = node1;
        node1->next->prev = node1;
    }
    else {
        // adjacent
        if (node1->next == node2){
            node1->prev->next = node2;
            node2->next->prev = node1;
            node2->prev = node1->prev;
            node1->prev = node2;
            node1->next = node2->next;
            node2->next = node1;
        }
        else {
            node2->prev->next = node1;
            node1->next->prev = node2;
            node1->prev = node2->prev;
            node2->prev = node1;
            node2->next = node1->next;
            node1->next = node2;
        }
    }
}

template<class T>
void LinkedList<T>::shuffle(int seed) {
    for (int i = 0; i < getSize(); i++) {
        swap(getNodeAtIndex(i), getNodeAtIndex(((i * i) + seed) % getSize()));
    }
}

template<class T>
void LinkedList<T>::print(bool reverse) const {
    if (this->isEmpty()) {
        std::cout << "The list is empty." << std::endl;
        return;
    }

    if (reverse) {
        // traverse in reverse order (last node to first node).

        Node<T> *node = this->getLastNode();

        do {
            std::cout << *node << std::endl;
            node = node->prev;
        }
        while (node != this->getLastNode());
    } else {
        // traverse in normal order (first node to last node).

        Node<T> *node = this->getFirstNode();

        do {
            std::cout << *node << std::endl;
            node = node->next;
        }
        while (node != this->getFirstNode());
    }
}

template<class T>
LinkedList<T> &LinkedList<T>::operator=(const LinkedList<T> &rhs) {
    if (this != &rhs) {
        removeAllNodes();
        for (int i = 0; i < rhs.getSize(); i++) {
            insertAtTheEnd(rhs.getNodeAtIndex(i)->data);
        }
    }
    return *this;
}

template<class T>
Node<T>* LinkedList<T>::findPrevious(const T& data) {
    int search_limit = 0;
    Node<T>* p = getFirstNode();
    while (search_limit <= size) {
        if (p->data == data) {
            return p->prev;
        }
        p = p->next;
        search_limit++;
    }
    return NULL;
}

#endif //LINKEDLIST_H
